<?php $__env->startSection('header'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script type="text/javascript">
$('#opd').select2({
      placeholder : 'Select Dinas',
      allowClear :true
});
</script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
        <form action="<?php echo e(route('stugas.lpaket')); ?>">
        <div class="input-group mb-3">
        <input value="<?php echo e(Request::get('keyword')); ?>" type="text" class="form-control col-md-10" name="keyword" placeholder="Cari Nama Pekerjaan">
          <div class="input-group-append">
            <button type="submit"  class="btn btn-primary"><i class="fas fa-search fa-sm"></i></button>
          </div>
        </div>
        </form>
    </div>
</div>

    

  <div class="card shadow mb-4">
    <!-- Card Header - Accordion -->
    <a href="#collapseCardExample" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardExample">
      <h6 class="m-0 font-weight-bold text-primary">Daftar Paket</h6>
    </a>

    <!-- Card Content - Collapse -->
    <div class="collapse show" id="collapseCardExample">
      <div class="card-body">

    <?php if(session('status')): ?>
      <div class="alert alert-success">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?> 
  
    <?php if(session('Status')): ?>
      <div class="alert alert-danger">
      <?php echo e(session('Status')); ?>

    </div>
    <?php endif; ?>
    
<table class="table table-striped">
    <thead>
      <tr>
        <th scope="col">No</th>
        <th scope="col">SKPD</th>
        <th scope="col">Nama Pekerjaan</th>
        <th scope="col">Pagu</th>
        <th scope="col">Tahun Anggaran</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $usulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td>
              <?php $__currentLoopData = $opd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($usul->id_opd == $opds->id): ?>
              <?php echo e($opds->opd); ?>

              <?php endif; ?> 
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td><a href="<?php echo e(route('stugas.view',[$usul->id])); ?>"><?php echo e($usul->namapaket); ?></a></td>
            <td>Rp.<?php echo e(number_format($usul->pagu,2)); ?></td>
            <td><?php echo e($usul->ta); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
        <tr>
        <td colspan=10><?php echo e($usulan->appends(request::all())->links()); ?></td>
        </tr>
      </tfoot>
  </table>
<a href="<?php echo e(route('stugas.index')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-arrow-circle-left fa-fw fa-sm"></i>Kembali</a>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sbadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simprodata\resources\views/stugas/lpaket.blade.php ENDPATH**/ ?>