<?php $__env->startSection('content'); ?> 
<div class="col-md-12">
    <div class="card shadow mb-4">
        <!-- Card Header - Accordion -->
        <a href="#collapseCardExample" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardExample">
          <h6 class="m-0 font-weight-bold text-primary">Detail BA Pembuktian</h6>
        </a>
    
        <!-- Card Content - Collapse -->
        <div class="collapse show" id="collapseCardExample">
          <div class="card-body">
<table class="table">
    <tr>
        <th class="bg-light" width="200">No Surat Pembuktian</th>
        <td colspan="3"><strong><?php echo e($pembuktian->nopembuktian); ?></strong></td>
    </tr>
    <tr>
        <th class="bg-light">Tanggal Pembuktian</th>
    <td colspan="3"><strong><?php echo e(Date::createFromDate($pembuktian->tglpembuktian)->format('j F Y')); ?></strong></td>
    </tr>
    <tr>
        <th class="bg-light">Nomor Surat Tugas</th>
    <td><strong><?php echo e($pembuktian->tugas->notugas); ?></strong></td>
    </tr>
    <tr>
        <th class="bg-light">Tanggal Surat Tugas</th>
    <td><strong><?php echo e(Date::createFromDate($pembuktian->tugas->tgltugas)->format('j F Y')); ?></strong></td>
    </tr>
    <tr>
        <th class="bg-light">Nomor Surat Usulan</th>
    <td><strong><?php echo e($pembuktian->tugas->usulan->nousul); ?></strong></td>
    </tr>
    <tr>
        <th class="bg-light">Tanggal Surat Usulan</th>
    <td><strong><?php echo e(Date::createFromDate($pembuktian->tugas->usulan->tglusul)->format('j F Y')); ?></strong></td>
    </tr>
    <tr>
        <th class="bg-light">Nama Pekerjaan</th>
    <td><strong><?php echo e($pembuktian->tugas->usulan->namapaket); ?></strong></td>
    </tr>
    <tr>
        <th class="bg-light">SKPD</th>
    <td><strong><?php echo e($pembuktian->tugas->opd->opd); ?></strong></td>
    </tr>
    <tr>
        <th class="bg-light">Sumber Dana</th>
    <td><strong><?php echo e($pembuktian->tugas->usulan->sumberdana); ?></strong></td>
    </tr>
    <tr>
        <th class="bg-light">Tahun Anggaran</th>
    <td><strong><?php echo e($pembuktian->tugas->usulan->ta); ?></strong></td>
    </tr>
    <tr>
        <th class="bg-light">Pagu Dana</th>
    <td><strong>Rp.<?php echo e(number_format($pembuktian->tugas->usulan->pagu)); ?></strong></td>
    </tr>
    <tr>
        <th class="bg-light">HPS</th>
    <td><strong>Rp.<?php echo e(number_format($pembuktian->tugas->usulan->hps)); ?></strong></td>
    </tr>
    <tr>
        <th class="bg-light">Jangka Waktu Pelaksanaan</th>
    <td><strong><?php echo e($pembuktian->tugas->usulan->jangkawaktu); ?></strong></td>
    </tr>
    <tr>
        <th class="bg-light">Pokja UKPBJ</th>
    <td><strong><?php echo e($pembuktian->tugas->pokja->namapokja); ?></strong></td>
    </tr>
    <tr>
        <th class="bg-light">Dokumen Pembuktian</th>
    <td><strong><a href="<?php echo e(route('pembuktian.download',[$pembuktian->id])); ?>"><i class="fas fa-download fa-fw fa-sm"></i><?php echo e($pembuktian->nama_file); ?></a></strong></td>
    </tr>
    <tr>
        <th class="bg-light">Foto Dokumentasi Pembuktian</th>
        <td> 
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="#"><img src="<?php echo e(asset('public/foto_dokumentasi/'.$d)); ?>" width="200px" class="img-thumbnail"></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
    </tr>
</table>
<a href="<?php echo e(route('pembuktian.index')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-arrow-circle-left fa-fw fa-sm"></i>Kembali</a>
          </div>
        </div>
    

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sbadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simprodata\resources\views/pembuktian/show.blade.php ENDPATH**/ ?>