<?php $__env->startSection('content'); ?>
<div class="col-md-12">
  <div class="card shadow mb-4">
      <!-- Card Header - Accordion -->
      <a href="#collapseCardExample" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardExample">
        <h6 class="m-0 font-weight-bold text-primary">Detail Usulan Lelang</h6>
      </a>
  
      <!-- Card Content - Collapse -->
      <div class="collapse show" id="collapseCardExample">
        <div class="card-body">
<table class="table">
  <tr>
      <th class="bg-light" width="200">No surat Usulan</th>
      <td colspan="3"><strong><?php echo e($usulan->nousul); ?></strong></td>
  </tr>
  <tr>
      <th class="bg-light">Tanggal Surat Usulan</th>
  <td colspan="3"><strong><?php echo e(Date::createFromDate($usulan->tglusul)->format('j F Y')); ?></strong></td>
  </tr>
  <tr>
    <th class="bg-light">Usulan</th>
<td><strong><?php echo e($usulan->usul); ?></strong></td>
</tr>
  <tr>
      <th class="bg-light">Nama Pekerjaan</th>
  <td><strong><?php echo e($usulan->namapaket); ?></strong></td>
  </tr>
  <tr>
      <th class="bg-light">SKPD</th>
  <td><strong><?php echo e($usulan->opd->opd); ?></strong></td>
  </tr>
  <tr>
      <th class="bg-light">Sumber Dana</th>
  <td><strong><?php echo e($usulan->sumberdana); ?></strong></td>
  </tr>
  <tr>
      <th class="bg-light">Tahun Anggaran</th>
  <td><strong><?php echo e($usulan->ta); ?></strong></td>
  </tr>
  <tr>
      <th class="bg-light">Pagu Dana</th>
  <td><strong>Rp.<?php echo e(number_format($usulan->pagu)); ?></strong></td>
  </tr>
  <tr>
      <th class="bg-light">HPS</th>
  <td><strong>Rp.<?php echo e(number_format($usulan->hps)); ?></strong></td>
  </tr>
  <tr>
    <th class="bg-light">Kode Rekening (MAK)</th>
<td><strong><?php echo e($usulan->mak); ?></strong></td>
</tr>
  <tr>
      <th class="bg-light">Jangka Waktu Pelaksanaan</th>
  <td><strong><?php echo e($usulan->jangkawaktu); ?></strong></td>
  </tr>
  <tr>
    <th class="bg-light">Kategori Pengadaan</th>
    <td><strong><?php echo e($usulan->kategori); ?></strong></td>
</tr>
  <tr>
      <th class="bg-light">File Surat Usulan</th>
  <td><strong><a href="<?php echo e(route('usulan.download',[$usulan->id])); ?>"><i class="fas fa-download fa-fw fa-sm"></i><?php echo e($usulan->tittle); ?></a></strong></td>
  </tr>
</table>
<a href="<?php echo e(route('usulan.index')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-arrow-circle-left fa-fw fa-sm"></i>Kembali</a>
        </div>
      </div>
  

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sbadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simprodata\resources\views/usulan/show.blade.php ENDPATH**/ ?>