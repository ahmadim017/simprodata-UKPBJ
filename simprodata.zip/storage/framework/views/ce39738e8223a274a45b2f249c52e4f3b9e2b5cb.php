<?php $__env->startSection('header'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script type="text/javascript">
$('#opd').select2({
      placeholder : 'Select Dinas',
      allowClear :true
});
$('#kategori').select2({
      placeholder : 'Select Kategori',
      allowClear :true
});
$('#dana').select2({
      placeholder : 'Select Sumber Dana',
      allowClear :true
});
$('#usul').select2({
      placeholder : 'Select Usulan',
      allowClear :true
});
$('#ta').select2({
      placeholder : 'Select Tahun Anggaran',
      allowClear :true
});
</script>
<script type="text/javascript">
  $(document).ready(function(){

      // Format mata uang.
      $( '#uang' ).mask('000.000.000.000.000', {reverse: true});
      $( '#hps' ).mask('000.000.000.000.000', {reverse: true});

  })
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-8">
    <div class="card shadow mb-4">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Tambah Usulan Lelang</h6>
      </div>
      
      <div class="card-body">
    
      <?php if(session('status')): ?>
          <div class="alert alert-success">
            <?php echo e(session('status')); ?>

          </div>
        <?php endif; ?> 
        <form action="<?php echo e(route('usulan.store')); ?>" enctype="multipart/form-data" method="POST" class="bg-white shadow-sm p-3">
        <?php echo csrf_field(); ?>
        <div class="row">
          <div class="col-6">
            <label for="">No Surat Usulan</label>
          <input type="text" name="nousul" class="form-control <?php echo e($errors->first('nousul') ? "is-invalid" : ""); ?>" placeholder="Nomor Surat Usulan">
          <div class="invalid-feedbeck"><?php echo e($errors->first('nousul')); ?></div>
        </div>
          <div class="col-6">
            <label for="">Tanggal Surat Usulan</label>
          <input type="date" class="form-control <?php echo e($errors->first('tglusul') ? "is-invalid" : ""); ?>" name="tglusul">
          <div class="invalid-feedbeck"><?php echo e($errors->first('tglusul')); ?></div>
        </div>
        </div><br>
        <div class="row">
          <div class="col-12">
            <label for="">Dinas</label>
          <select name="id_opd" id="opd" class="form-control <?php echo e($errors->first('id_opd') ? "is-invalid" : ""); ?>">
                <option value=""></option>
                <?php $__currentLoopData = $opd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($opd->id); ?>"><?php echo e($opd->opd); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div class="invalid-feedbeck"><?php echo e($errors->first('id_opd')); ?></div>
          </div>
        </div>
        <br>
        <div class="row">
          <div class="col-12">
            <label for="">Nama Pekerjaan</label> 
            <input type="text" name="namapaket" class="form-control <?php echo e($errors->first('namapaket') ? "is-invalid" : ""); ?>" placeholder="Nama Paket">
            <div class="invalid-feedbeck"> <?php echo e($errors->first('namapaket')); ?></div>
          </div>
        </div>
        <br>
        <div class="row">
        <div class="col-6">
          <label for="">Sumber Dana</label>
          <select name="sumberdana" id="dana" class="form-control <?php echo e($errors->first('sumberdana') ? "is-invalid" : ""); ?>">
              <option value=""></option>
              <?php $__currentLoopData = $dana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dana): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($dana->sumberdana); ?>"><?php echo e($dana->sumberdana); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select><br><br>
          <div class="invalid-feedbeck"> <?php echo e($errors->first('sumberdana')); ?></div>
        </div>
        <div class="col-6">
          <label for="">Tahun Anggaran</label>
          <select name="ta" id="ta" class="form-control <?php echo e($errors->first('ta') ? "is-invalid" : ""); ?>">
            <option value=""></option>
            <?php $__currentLoopData = $ta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($ta->tahunanggaran); ?>"><?php echo e($ta->tahunanggaran); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <div class="invalid-feedbeck"> <?php echo e($errors->first('ta')); ?></div>
        </div>
        </div>
        <div class="row">
          <div class="col-6">
            <label for="">Pagu</label>
            <input type="text" name="pagu" id="uang" class="form-control <?php echo e($errors->first('pagu') ? "is-invalid" : ""); ?>" placeholder="Pagu">
            <div class="invalid-feedbeck"> <?php echo e($errors->first('pagu')); ?></div>
          </div>
          <div class="col-6">
            <label for="">Hps</label>
            <input type="text" name="hps" id="hps" class="form-control <?php echo e($errors->first('hps') ? "is-invalid" : ""); ?>" placeholder="Hps">
            <div class="invalid-feedbeck"> <?php echo e($errors->first('hps')); ?></div>
          </div>
        </div><br>
        <div class="row">
          <div class="col-6">
            <label for="">Kategori</label>
            <select name="kategori" id="kategori" class="form-control <?php echo e($errors->first('kategori') ? "is-invalid" : ""); ?>">
              <option value=""></option>
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($kategori->kategori); ?>"><?php echo e($kategori->kategori); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div class="invalid-feedbeck"> <?php echo e($errors->first('kategori')); ?></div>
          </div>
          <div class="col-6">
            <label for="">Usulan</label>
            <select name="usul" id="usul" class="form-control <?php echo e($errors->first('usul') ? "is-invalid" : ""); ?>">
                <option value=""></option>
                <?php $__currentLoopData = $usul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($usul->usul); ?>"><?php echo e($usul->usul); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div class="invalid-feedbeck"> <?php echo e($errors->first('usul')); ?></div>
          </div>
        </div><br>
        <div class="row">
          <div class="col-6">
            <label for="">Jangka Waktu Pelaksanaan</label>
            <input type="text" name="jangkawaktu" placeholder="Waktu Pelaksanaan" class="form-control <?php echo e($errors->first('jangkawaktu') ? "is-invalid" : ""); ?>">
            <div class="invalid-feedbeck"> <?php echo e($errors->first('jangkawaktu')); ?></div>
          </div>
        </div><br>
        <div class="row">
          <div class="col-6">
            <label for="">Kode Anggaran</label>
            <input type="text" name="mak" placeholder="Mak" class="form-control <?php echo e($errors->first('mak') ? "is-invalid" : ""); ?>">
            <div class="invalid-feedbeck"> <?php echo e($errors->first('mak')); ?></div>
          </div>
        </div><br>
        <div class="row">
          <div class="col-6">
            <label for="">File Usulan</label>
            <input type="file" class="form-control <?php echo e($errors->first('file_usulan') ? "is-invalid" : ""); ?>" name="file_usulan">
          <div class="invalid-feedbeck"> <?php echo e($errors->first('file_usulan')); ?></div>
            <small>*file bertipe PDF maximal size 5mb</small>
          </div>
        </div><br>
        <button type="submit" class="btn btn-primary btn-sm" value="Simpan"><i class="fa fa-save fa-sm"></i> Simpan</button>
        <a href="<?php echo e(route('usulan.index')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-arrow-circle-left fa-fw fa-sm"></i>Kembali</a>
        </form>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sbadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simprodata\resources\views/usulan/create.blade.php ENDPATH**/ ?>