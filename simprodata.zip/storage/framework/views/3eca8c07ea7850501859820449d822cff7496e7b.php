<?php $__env->startSection('content'); ?>
<div class="card shadow mb-4">
    <div class="card">
        <div class="card-body">
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            Welcome, <span class="badge badge-primary"><?php echo e(auth::user()->name); ?></span> <br>
            You are logged in!
        </div>
    </div>
</div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sbadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simprodata\resources\views/user.blade.php ENDPATH**/ ?>