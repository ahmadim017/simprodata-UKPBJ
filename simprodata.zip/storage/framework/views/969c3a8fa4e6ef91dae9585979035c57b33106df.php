<?php $__env->startSection('header'); ?>
<link href="<?php echo e(asset('public/sbadmin/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script src="<?php echo e(asset('public/sbadmin/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/sbadmin/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/sbadmin/js/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
    <form action="<?php echo e(route('stugas.index')); ?>">
    <div class="input-group mb-3">
    <input value="<?php echo e(Request::get('keyword')); ?>" type="text" class="form-control col-md-10" name="keyword" placeholder="Cari Nama Pekerjaan">
      <div class="input-group-append">
        <button type="submit"  class="btn btn-primary"><i class="fas fa-search fa-sm"></i></button>
      </div>
    </div>
    </form>
    </div>
  </div>

  <div class="row">
    <div class="col-md-12 text-right">
    <a href="<?php echo e(route('stugas.lpaket')); ?>" class="btn btn-info btn-sm"><i class="fa fa-plus-circle fa-sm"></i> Buat Paket</a>
    </div> 
</div><br>

  <div class="card shadow mb-4">
    <!-- Card Header - Accordion -->
    <a href="#collapseCardExample" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardExample">
      <h6 class="m-0 font-weight-bold text-primary">Data Surat Tugas</h6>
    </a>

    <!-- Card Content - Collapse -->
    <div class="collapse show" id="collapseCardExample">
      <div class="card-body">

    <?php if(session('status')): ?>
      <div class="alert alert-success">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?> 
  
    <?php if(session('Status')): ?>
      <div class="alert alert-danger">
      <?php echo e(session('Status')); ?>

    </div>
    <?php endif; ?>
    <div class="table-responsive">    
<table class="table table-striped" id="dataTable">
    <thead>
      <tr>
        <th scope="col">No</th>
        <th scope="col">No Surat Tugas</th>
        <th scope="col">Tanggal Surat</th>
        <th scope="col">SKPD</th>
        <th scope="col">Nama Pekerjaan</th>
        <th scope="col">Pokja</th>
        <th scope="col">Tahun Anggaran</th>
        <?php if(Auth::user()->roles == "ADMIN"): ?>
        <th scope="col">Aksi</th>
        <?php endif; ?>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
        <td><a href="<?php echo e(route('stugas.show',[$t->id])); ?>"><?php echo e($t->notugas); ?></a></td>
          <td><?php echo e(Date::createFromDate($t->tgltugas)->format('j F Y')); ?></td>
          <td>
           <?php echo e($t->opd->opd); ?>

          </td>
          <td>
           <?php echo e($t->usulan->namapaket); ?>

          </td>
          <td>
           <?php echo e($t->pokja->namapokja); ?>

          </td>
          <td>
            <?php echo e($t->usulan->ta); ?>

          </td>
          <?php if(Auth::user()->roles == "ADMIN"): ?>
          <td><a href="<?php echo e(route('stugas.edit',[$t->id])); ?>" class="btn btn-primary btn-sm">Edit</a> 
          <form onsubmit="return confirm('Apakah Anda Yakin Ingin Menghapus?')" action="<?php echo e(route('stugas.destroy',[$t->id])); ?>" class="d-inline" method="POST">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="_method" value="DELETE">
          <input type="submit" value="Delete" class="btn btn-danger btn-sm">

          </form>
          </td>
          <?php endif; ?>
    </tr> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      
    </tbody>
  </table>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sbadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simprodata\resources\views/stugas/index.blade.php ENDPATH**/ ?>