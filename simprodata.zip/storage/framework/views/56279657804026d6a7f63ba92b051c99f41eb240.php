<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
    <form action="<?php echo e(route('pokja.index')); ?>">
    <div class="input-group mb-3">
    <input value="<?php echo e(Request::get('keyword')); ?>" type="text" class="form-control col-md-10" name="keyword" placeholder="Cari Nama Pekerjaan">
      <div class="input-group-append">
        <button type="submit"  class="btn btn-primary"><i class="fas fa-search fa-sm"></i></button>
      </div>
    </div>
    </form>
    </div>
  </div>

<div class="row">
    <div class="col-md-12 text-right">
    <a href="<?php echo e(route('pokja.create')); ?>" class="btn btn-info btn-sm"><i class="fa fa-plus-circle fa-fw fa-sm"></i>Tambah Pokja</a>
    </div> 
</div><br>

<div class="card shadow mb-4">
    <!-- Card Header - Accordion -->
    <a href="#collapseCardExample" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardExample">
      <h6 class="m-0 font-weight-bold text-primary">Data Pokja ULP</h6>
    </a>

    <!-- Card Content - Collapse -->
    <div class="collapse show" id="collapseCardExample">
      <div class="card-body">

    <?php if(session('status')): ?>
      <div class="alert alert-success">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?> 
  
    <?php if(session('Status')): ?>
      <div class="alert alert-danger">
      <?php echo e(session('Status')); ?>

    </div>
    <?php endif; ?>
    
<table class="table table-striped">
    <thead>
      <tr>
        <th scope="col">No</th>
        <th scope="col">Nama</th>
        <th scope="col">Status</th>
        <th scope="col">Tanggal Pembuatan</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $pokja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><a href="<?php echo e(route('pokja.show',[$pokja->id])); ?>"><?php echo e($pokja->namapokja); ?></a></td>
            <td><?php if($pokja->status == 'ACTIVE'): ?>
              <span class="badge badge-info"><?php echo e($pokja->status); ?></span>
              <?php else: ?> 
              <span class="badge badge-warning"><?php echo e($pokja->status); ?></span>
              <?php endif; ?></td>
            <td><?php echo e($pokja->tglpembuatan); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sbadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simprodata\resources\views/pokja/index.blade.php ENDPATH**/ ?>