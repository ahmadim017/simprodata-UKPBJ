<table>
    <thead>
        <tr><th colspan="10" ><b>Pemerintah Kabupaten Penajam Paser Utara</b></th></tr>
        <tr><th colspan="10" ><b>Sekretariat Daerah Bagian Barang Jasa</b></th></tr>
        <tr><th colspan="10" ><b></b></th></tr>

        <tr>
            <th>No</th>
            <th>No Usulan</th>
            <th>Tanggal Usulan</th>
            <th>Nama Paket</th>
            <th>SKPD</th>
            <th>Sumber Dana</th>
            <th>Tahun Anggaran</th>
            <th>PAGU</th>
            <th>HPS</th>
            <th>Waktu Pelaksanaan</th>
            <th>Kategori</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($u->nousul); ?></td>
        <td><?php echo e(Date::createFromDate($u->tglusul)->format('j F Y')); ?></td>
        <td><?php echo e($u->namapaket); ?></td>
        <td><?php echo e($u->opd->opd); ?></td>
        <td><?php echo e($u->sumberdana); ?></td>
        <td><?php echo e($u->ta); ?></td>
        <td><?php echo e(number_format($u->pagu)); ?></td>
        <td><?php echo e(number_format($u->hps)); ?></td>
        <td><?php echo e($u->jangkawaktu); ?></td>
        <td><?php echo e($u->kategori); ?></td>
        </tr> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\simprodata\resources\views/laporanulp/export.blade.php ENDPATH**/ ?>