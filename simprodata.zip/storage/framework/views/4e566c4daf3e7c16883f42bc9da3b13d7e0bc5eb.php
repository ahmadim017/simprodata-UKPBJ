<?php $__env->startSection('header'); ?>
<link href="<?php echo e(asset('public/sbadmin/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script src="<?php echo e(asset('public/sbadmin/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/sbadmin/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/sbadmin/js/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="row">
    <div class="col-md-12 text-right">
    <a href="<?php echo e(route('hasillelang.create')); ?>" class="btn btn-info btn-sm"><i class="fa fa-plus-circle fa-fw fa-sm"></i>Buat Hasil Lelang</a>
    </div> 
</div><br>

  <div class="card shadow mb-4">
    <!-- Card Header - Accordion -->
    <a href="#collapseCardExample" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardExample">
      <h6 class="m-0 font-weight-bold text-primary">Data Hasil Lelang UKPBJ</h6>
    </a>

    <!-- Card Content - Collapse -->
    <div class="collapse show" id="collapseCardExample">
      <div class="card-body">

    <?php if(session('status')): ?>
      <div class="alert alert-success">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?> 
  
    <?php if(session('Status')): ?>
      <div class="alert alert-danger">
      <?php echo e(session('Status')); ?>

    </div>
    <?php endif; ?>
    <div class="table-responsive">  
<table class="table table-striped" id="dataTable" width="100%" cellspacing="0">
    <thead>
      <tr>
        <th scope="col">No</th>
        <th scope="col">No Hasil Lelang</th>
        <th scope="col">Tanggal Hasil Lelang</th>
        <th scope="col">Nama Pekerjaan</th>
        <th scope="col">Sumber Dana</th>
        <th scope="col">Tahun Anggaran</th>
        <?php if(Auth::user()->roles == "ADMIN"): ?>
        <th scope="col">Aksi</th>
        <?php endif; ?>
      </tr>
    </thead>
    <tbody>
       <?php $__currentLoopData = $hasillelang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
       <td><?php echo e($loop->iteration); ?></td>
       <td><a href="<?php echo e(route('hasillelang.show',[$hl->id])); ?>"><?php echo e($hl->nohasil); ?></a></td>
       <td><?php echo e(Date::createFromDate($hl->tglhasil)->format('j F Y')); ?></td>
          <td>
          <?php echo e($hl->tugas->usulan->namapaket); ?>

          </td>
          <td>
            <?php echo e($hl->tugas->usulan->sumberdana); ?>

          </td>
          <td>
            <?php echo e($hl->tugas->usulan->ta); ?>

        </td>
        <?php if(Auth::user()->roles == "ADMIN"): ?>
      <td><a href="<?php echo e(route('hasillelang.edit',[$hl->id])); ?>" class="btn btn-primary btn-sm">Edit</a> 
      <form onsubmit="return confirm('Apakah Anda Yakin Ingin Menghapus?')" action="<?php echo e(route('hasillelang.destroy',[$hl->id])); ?>" class="d-inline" method="POST">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="_method" value="DELETE">
          <input type="submit" value="Delete" class="btn btn-danger btn-sm">
          </form>
          </form>
          </td>
          <?php endif; ?>
    </tr> 
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
       
      
      
    </tbody>
  </table>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sbadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simprodata\resources\views/hasillelang/index.blade.php ENDPATH**/ ?>