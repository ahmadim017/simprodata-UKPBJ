<?php $__env->startSection('header'); ?>
<link href="<?php echo e(asset('public/sbadmin/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script src="<?php echo e(asset('public/sbadmin/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/sbadmin/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/sbadmin/js/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12 text-right">
    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-info btn-sm"><i class="fa fa-plus-circle fa-sm"></i>Tambah User</a>
    </div> 
</div><br>

<div class="card shadow mb-4">
    <!-- Card Header - Accordion -->
    <a href="#collapseCardExample" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardExample">
      <h6 class="m-0 font-weight-bold text-primary">Data User</h6>
    </a>

    <!-- Card Content - Collapse -->
    <div class="collapse show" id="collapseCardExample">
      <div class="card-body">

    <?php if(session('status')): ?>
      <div class="alert alert-success">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?> 
  
    <?php if(session('Status')): ?>
      <div class="alert alert-danger">
      <?php echo e(session('Status')); ?>

    </div>
    <?php endif; ?>
<div class="table-responsive">    
<table class="table table-striped" id="dataTable">
    <thead>
      <tr>
        <th scope="col">Username</th>
        <th scope="col">Nama</th>
        <th scope="col">Email</th>
        <th scope="col">Role</th>
        <th scope="col">Status</th>
        <th scope="col">Aksi</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
            <td><?php echo e($user->username); ?></td>
            <td><a href="<?php echo e(route('users.show',[$user->id])); ?>"><?php echo e($user->name); ?></a></td>
            <td><?php echo e($user->email); ?></td>
            <td>
            <span class="badge badge-primary"><?php echo e(($user->roles)); ?></span>
            </td>
            <td>
                <?php if($user->status == 'ACTIVE'): ?>
                <span class="badge badge-info"><?php echo e($user->status); ?></span>
                <?php else: ?> 
                <span class="badge badge-warning"><?php echo e($user->status); ?></span>
                <?php endif; ?>
            </td>
          <td><a href="<?php echo e(route('users.edit',[$user->id])); ?>" class="btn btn-primary btn-sm">Edit</a> 
          <form onsubmit="return confirm('Apakah Anda Yakin Ingin Menghapus?')" class="d-inline" action="<?php echo e(route('users.destroy',[$user->id])); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="_method" value="DELETE">
          <input type="submit" value="Delete" class="btn btn-danger btn-sm">
          </form>
            </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sbadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simprodata\resources\views/users/index.blade.php ENDPATH**/ ?>