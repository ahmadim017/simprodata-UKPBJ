 

<?php $__env->startSection('content'); ?>
    <div class="col-md-8">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Edit User</h6>
              </div>
        <div class="card-body">

        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('users.update',[$user->id])); ?>" enctype="multipart/form-data" method="POST" class="bg-white shadow-sm p-3">
        <?php echo csrf_field(); ?>
        <input type="hidden" value="PUT" name="_method">
        <label for="">Username</label>
        <input type="text" value="<?php echo e($user->username); ?>" class="form-control" disabled><br>
        <label for="">Nama</label>
        <input type="text" value="<?php echo e($user->name); ?>" name="name" class="form-control"><br>
        <label for="">Email</label>
        <input type="text" value="<?php echo e($user->email); ?>" class="form-control" disabled><br>
        <label for="">Roles</label>
        <br>
        <div class="form-radio form-radio-inline">
            <input type="radio" name="roles" id="ADMIN" value="ADMIN" <?php echo e($user->roles == "ADMIN" ? "checked" : ""); ?>>
            <label for="form-radio-label" for="ADMIN">Admin</label>
        </div>
        <div class="form-radio form-radio-inline">
            <input type="radio" name="roles" id="USER" value="USER" <?php echo e($user->roles == "USER" ? "checked" : ""); ?>>
            <label for="form-radio-label" for="USER">User</label>
        </div>
        <div class="form-radio form-radio-inline">
            <input type="radio" name="roles" id="AUDITOR" value="AUDITOR" <?php echo e($user->roles == "AUDITOR" ? "checked" : ""); ?>>
            <label for="form-radio-label" for="AUDITOR">Auditor</label>
        </div>
        <div class="form-radio form-radio-inline">
            <input type="radio" name="roles" id="POKJA" value="POKJA" <?php echo e($user->roles == "POKJA" ? "checked" : ""); ?>>
            <label for="form-radio-label" for="AUDITOR">Pokja</label>
        </div><br>
        <label for="">Status</label>
        <br>
        <div class="form-radio form-radio-inline">
            <input type="radio" name="status" id="ACTIVE" value="ACTIVE" <?php echo e($user->status == "ACTIVE" ? "checked" : ""); ?>>
            <label for="form-radio-label" for="ACTIVE">ACTIVE</label>
        </div>
        <div class="form-radio form-radio-inline">
            <input type="radio" name="status" id="INACTIVE" value="INACTIVE" <?php echo e($user->status == "INACTIVE" ? "checked" : ""); ?>>
            <label for="form-radio-label" for="INACTIVE">INACTIVE</label>
        </div><br>
        <label for="telpon">Telpon</label>
        <input type="text" class="form-control <?php echo e($errors->first('phone') ? "IS-INVALID" : ""); ?>" name="telpon" id="telpon" value="<?php echo e($user->telpon); ?>" placeholder="Nomor HP/Telp">
        <br>
        <label for="alamat">Alamat</label>
        <textarea name="alamat" id="alamat" class="form-control <?php echo e($errors->first('alamat') ? "IS-INVALID" : ""); ?>"><?php echo e($user->alamat); ?></textarea><br>
        <label for="">Avatar</label>
        <br>
        Current image :
        <br>
        <?php if($user->avatar): ?> <img src="<?php echo e(asset('storage/App/public/'.$user->avatar)); ?>" width="120px"><br><br>
        <?php else: ?>
        No Image 
        <?php endif; ?>
        <input type="file" class="form-control" name="avatar">
        <small class="text-muted">* kosongkan  jika tidak ingin mengubah avatar</small>
        <br>
        <button type="submit" class="btn btn-primary btn-sm" value="Simpan"><i class="fa fa-save fa-sm"></i> Simpan</button>
        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-arrow-circle-left fa-fw fa-sm"></i>Kembali</a>
        </form>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sbadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simprodata\resources\views/users/edit.blade.php ENDPATH**/ ?>