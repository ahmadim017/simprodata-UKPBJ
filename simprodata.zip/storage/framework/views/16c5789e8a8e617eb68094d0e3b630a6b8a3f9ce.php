<?php $__env->startSection('content'); ?>
<div class="card border-left-primary shadow h-100 py-2">
    <div class="card-body box-profile">
      <div class="text-center">
        <img class="img-profile rounded-circle"
             src="<?php echo e(asset('storage/app/public/'.$user->avatar)); ?>"
             alt="User profile picture" width="120px">
      </div><br>

      <h3 class="profile-username text-center"><?php echo e($user->name); ?></h3>

      <p class="text-muted text-center"><?php echo e($user->email); ?></p>

      <ul class="list-group list-group-unbordered mb-3">
        <li class="list-group-item">
          <b>Username</b> <a class="float-right"><?php echo e($user->username); ?></a>
        </li>
        <li class="list-group-item">
          <b>Telp/Hp</b> <a class="float-right"><?php echo e($user->telpon); ?></a>
        </li>
        <li class="list-group-item">
          <b>Alamat</b> <a class="float-right"><?php echo e($user->alamat); ?></a>
        </li>
        <li class="list-group-item">
        <b>Role</b> <a class="float-right"><?php echo e($user->roles); ?></a>
          </li>
          <li class="list-group-item">
              <b>Status</b> <a class="float-right"><?php echo e($user->status); ?></a>
            </li>
      </ul>

    <a href="<?php echo e(route('profil.edit',[$user->id])); ?>" class="btn btn-primary btn-sm">Edit</a>

    </div>
    <!-- /.card-body -->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sbadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simprodata\resources\views/profil/show.blade.php ENDPATH**/ ?>