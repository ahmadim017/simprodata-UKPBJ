<?php $__env->startSection('header'); ?>
<link href="<?php echo e(asset('public/sbadmin/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script src="<?php echo e(asset('public/sbadmin/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/sbadmin/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/sbadmin/js/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12 text-right">
    <a href="<?php echo e(route('opd.create')); ?>" class="btn btn-info btn-sm"><i class="fa fa-plus-circle fa-sm"></i>Tambah Dinas</a>
    </div> 
</div><br>

<div class="card shadow mb-4">
    <!-- Card Header - Accordion -->
    <a href="#collapseCardExample" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardExample">
      <h6 class="m-0 font-weight-bold text-primary">Data Dinas</h6>
    </a>

    <!-- Card Content - Collapse -->
    <div class="collapse show" id="collapseCardExample">
      <div class="card-body">

    <?php if(session('status')): ?>
      <div class="alert alert-success">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?> 
  
    <?php if(session('Status')): ?>
      <div class="alert alert-danger">
      <?php echo e(session('Status')); ?>

    </div>
    <?php endif; ?>
    <div class="table-responsive">    
<table class="table table-striped" id="dataTable">
    <thead>
      <tr>
        <th scope="col">Nama Dinas</th>
        <th scope="col">Status</th>
        <th scope="col">Aksi</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $opd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
            <td><?php echo e($opd->opd); ?></td>
            <td>
                <?php if($opd->status == 'ACTIVE'): ?>
                <span class="badge badge-info"><?php echo e($opd->status); ?></span>
                <?php else: ?> 
                <span class="badge badge-warning"><?php echo e($opd->status); ?></span>
                <?php endif; ?>
            </td>
          <td><a href="<?php echo e(route('opd.edit',[$opd->id])); ?>" class="btn btn-primary btn-sm">Edit</a> 
          </form>
            </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sbadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simprodata\resources\views/opd/index.blade.php ENDPATH**/ ?>