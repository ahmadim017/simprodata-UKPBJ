<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Laporan Usulan Lelang</h6>
            </div>
            <div class="card-body">
            <form action="<?php echo e(route('laporanulp.cetak')); ?>" class="bg-white shadow-sm p-3">
            <h5 class="font-weight-bold text-primary" >Laporan Per SKPD</h5>
            <div class="row">
                <div class="col-10">
                    <label for="">SKPD</label>
                    <select name="opd" id="" class="form-control">
                        <option value=""></option>
                        <?php $__currentLoopData = $opd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($p->id); ?>"><?php echo e($p->opd); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div><br>
            <h5 class="font-weight-bold text-primary">Laporan Per Kategori Pengadaan</h5>
            <div class="row">
                <div class="col-10">
                    <label for="">Kategori Pengadaan</label>
                    <select name="kategori" id="kategori" class="form-control">
                        <option value=""></option>
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($k->kategori); ?>"><?php echo e($k->kategori); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div><br>

            <h5 class="font-weight-bold text-primary">Laporan Perperiode</h5>
            <div class="row">
                <div class="col-5">
                    <label for="">Tanggal</label>
                <input type="date" class="form-control <?php echo e($errors->first('date1') ? "is-invalid" : ""); ?>" name="date1" >
                <div class="invalid-feedbeck"><?php echo e($errors->first('date1')); ?></div>
                </div>
                <div class="col-5">
                    <label for="">Tanggal</label>
                    <input type="date" class="form-control <?php echo e($errors->first('date2') ? "is-invalid" : ""); ?>" name="date2" >
                    <div class="invalid-feedbeck"><?php echo e($errors->first('date2')); ?></div>
                </div>
                </div><br>
            <button type="submit" class="btn btn-primary btn-sm"><i class="far fa-file-excel fa-fw"></i>Cetak</button>
            </form>
            
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sbadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simprodata\resources\views/laporanulp/usulanlelang.blade.php ENDPATH**/ ?>