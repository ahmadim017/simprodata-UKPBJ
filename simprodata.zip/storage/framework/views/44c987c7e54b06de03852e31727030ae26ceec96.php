<?php $__env->startSection('content'); ?>
<div class="col-md-8">
    <div class="card shadow mb-4">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Tambah User</h6>
      </div>
      
      <div class="card-body">
    
      <?php if(session('status')): ?>
          <div class="alert alert-success">
            <?php echo e(session('status')); ?>

          </div>
        <?php endif; ?> 
    
      <form enctype="multipart/form-data"  class="bg-white shadow-sm p-3" action="<?php echo e(route('users.store')); ?>" method="POST">
    
          <?php echo csrf_field(); ?>
        <label for="name">Name</label>
      <input class="form-control <?php echo e($errors->first('name') ? "is-invalid" : ""); ?>" value="<?php echo e(old('name')); ?>" placeholder="Full Name" type="text" name="name" id="name"/>
        <div class="invalid-feedbeck">
        <?php echo e($errors->first('name')); ?></div>  
        <br>
        <label for="username">Username</label>
        <input class="form-control <?php echo e($errors->first('username') ? "is-invalid" : ""); ?>" value="<?php echo e(old('username')); ?>" placeholder="username" type="text" name="username" id="username"/>
        <div class="invalid-feedbeck">
          <?php echo e($errors->first('username')); ?>

        </div>
        <br>
        <label for="">Roles</label>
          <br>
          <input class=" <?php echo e($errors->first('roles') ? "is-invalid" : ""); ?>" type="checkbox" name="roles" id="admin"  value="ADMIN"> 
            <label for="ADMIN">Admin</label>
          <input class=" <?php echo e($errors->first('roles') ? "is-invalid" : ""); ?>" type="checkbox" name="roles" id="user" value="USER"> 
            <label for="USER">User</label>
          <input class=" <?php echo e($errors->first('roles') ? "is-invalid" : ""); ?>" type="checkbox" name="roles" id="auditor" value="AUDITOR"> 
            <label for="AUDITOR">Auditor</label>
            <input class=" <?php echo e($errors->first('roles') ? "is-invalid" : ""); ?>" type="checkbox" name="roles" id="pokja" value="POKJA"> 
            <label for="AUDITOR">Pokja</label>
          <br>
          <label for="phone">No Hp</label> 
          <br>
          <input type="text" name="telpon" value="<?php echo e(old('telpon')); ?>" class="form-control <?php echo e($errors->first('telpon') ? "is-invalid" : ""); ?>">
          <div class="invalid-feedbeck">
            <?php echo e($errors->first('telpon')); ?>

          </div>
          <br>
          <label for="address">Alamat</label>
          <textarea name="alamat" id="alamat"  class="form-control <?php echo e($errors->first('alamat') ? "is-invalid" : ""); ?>"><?php echo e(old('alamat')); ?></textarea>
          <div class="invalid-feedbeck">
            <?php echo e($errors->first('alamat')); ?>

          </div>
          <br>
          <label for="avatar">Avatar image</label>
          <br>
          <input id="avatar" name="avatar" type="file" class="form-control <?php echo e($errors->first('avatar') ? "is-invalid" : ""); ?>">
          <div class="invalid-feedbeck">
            <?php echo e($errors->first('avatar')); ?>

          </div>
          <hr class="my-3">
          <label for="email">Email</label>
          <input class="form-control <?php echo e($errors->first('email') ? "is-invalid" : ""); ?>" value="<?php echo e(old('email')); ?>" placeholder="user@mail.com" type="text" name="email" id="email"/>
          <div class="invalid-feedbeck">
            <?php echo e($errors->first('email')); ?>

          </div>
          <br>
          <label for="password">Password</label>
          <input class="form-control <?php echo e($errors->first('password') ? "is-invalid" : ""); ?>" placeholder="password" type="password" name="password" id="password"/>
          <div class="invalid-feedbeck">
            <?php echo e($errors->first('password')); ?>

          </div>
          <br>
          <label for="password_confirmation">Password Confirmation</label>
          <input class="form-control <?php echo e($errors->first('password_confirmation') ? "is-invalid" : ""); ?>" placeholder="password confirmation" type="password" name="password_confirmation" id="password_confirmation"/>
          <div class="invalid-feedbeck">
            <?php echo e($errors->first('password_confrimation')); ?>

          </div>
          <br>
          <button class="btn btn-primary btn-sm" type="submit" value="Save"><i class="fa fa-save fa-sm"></i> Simpan</button>
        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-arrow-circle-left fa-fw fa-sm"></i>Kembali</a>
        </form>
      </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sbadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simprodata\resources\views/users/create.blade.php ENDPATH**/ ?>