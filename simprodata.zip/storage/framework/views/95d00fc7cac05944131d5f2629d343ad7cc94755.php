<?php $__env->startSection('content'); ?>
<div class="col-md-8">
    <div class="card shadow mb-4">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Edit Pokja</h6>
      </div>
      
      <div class="card-body">
    
      <?php if(session('status')): ?>
          <div class="alert alert-success">
            <?php echo e(session('status')); ?>

          </div>
        <?php endif; ?> 
        
        <form enctype="multipart/form-data" action="<?php echo e(route('pokja.update',[$pokja->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" value="PUT" name="_method">
        <label for="name">Nama Pokja</label>
        <input class="form-control" placeholder="Group Pokja" type="text" name="namapokja" value="<?php echo e($pokja->namapokja); ?>"/>
        <br>
        <label for="">Status</label>
        <br>
        <div class="form-radio form-radio-inline">
            <input type="radio" name="status" id="ACTIVE" value="ACTIVE" <?php echo e($pokja->status == "ACTIVE" ? "checked" : ""); ?>>
            <label for="form-radio-label" for="ACTIVE">ACTIVE</label>
        </div>
        <div class="form-radio form-radio-inline">
            <input type="radio" name="status" id="INACTIVE" value="INACTIVE" <?php echo e($pokja->status == "INACTIVE" ? "checked" : ""); ?>>
            <label for="form-radio-label" for="INACTIVE">INACTIVE</label>
        </div><br>
        <div class="row">
            <div class="col-6">
                <label for="">Tanggal Pembuatan</label>
            <input type="date" class="form-control" name="tglpembuatan" value="<?php echo e($pokja->tglpembuatan); ?>">
            </div> 
        </div>
          <br>
          <div class="row">
            <div class="col-12">
              <div class="breadcrumb">
                Daftar Pegawai UKPBJ
            </div>
            <table  class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama</th>
                        <th>User ID</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $datapokja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($da == $d->id): ?>
                        <tr>
                                <td>#</td>
                                <td><?php echo e($d->name); ?></td>
                                <td><?php echo e($d->username); ?></td>
                                <td><?php echo e($d->email); ?></td> 
                        </tr>
                        <?php endif; ?> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div>
          </div><br>
          <button class="btn btn-primary btn-sm" value="submit" type="submit"><i class="fa fa-save fa-sm"></i> Simpan</button>
          <a href="#collapseCardExample" data-toggle="collapse" class="btn btn-info btn-sm"><i class="fa fa-plus-circle fa-fw fa-sm"></i>Ubah Data Pokja</a>
          <a href="<?php echo e(route('pokja.index')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-arrow-circle-left fa-fw fa-sm"></i>Kembali</a><br>
          <br>
          <div class="collapse" id="collapseCardExample">
          <div class="row"> 
            <div class="col-12">
              <div class="breadcrumb">
                Daftar Pegawai UKPBJ
            </div>
      <table  class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Nama</th>
                <th>User ID</th>
                <th>Email</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><input type="checkbox" class="checkbox" name="id_user[]" value="<?php echo e($u->id); ?>"/></td>
                <td><?php echo e($u->name); ?></td>
                <td><?php echo e($u->username); ?></td>
                <td><?php echo e($u->email); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
            </div>
          </div>
          </div><br>
      </form>
<br> 
     
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sbadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simprodata\resources\views/pokja/edit.blade.php ENDPATH**/ ?>