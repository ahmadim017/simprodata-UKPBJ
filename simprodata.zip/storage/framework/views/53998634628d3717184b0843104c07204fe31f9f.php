<?php $__env->startSection('content'); ?>
<div class="col-md-10">
    <div class="card shadow mb-4">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Daftar Pegawai Pokja</h6>
      </div>
      
      <div class="card-body">
    
      <?php if(session('status')): ?>
          <div class="alert alert-success">
            <?php echo e(session('status')); ?>

          </div>
        <?php endif; ?> 
        <form action="<?php echo e(route('datapokja.store')); ?>" enctype="multipart/form-data" method="POST" class="bg-white shadow-sm p-3">
        <?php echo csrf_field(); ?>
        <input type="hidden" value="<?php echo e($pokja->id); ?>" name="id_pokja">
        <div class="breadcrumb">
            Daftar Pegawai UKPBJ
        </div>
<table  class="table">
    <thead>
        <tr>
            <th>#</th>
            <th>Nama</th>
            <th>User ID</th>
            <th>Email</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><input type="checkbox" class="checkbox" name="id_user" value="<?php echo e($u->id); ?>"/></td>
            <td><?php echo e($u->name); ?></td>
            <td><?php echo e($u->username); ?></td>
            <td><?php echo e($u->email); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>  <hr>
        <button type="submit" class="btn btn-primary btn-sm" value="Simpan"><i class="fa fa-save fa-sm"></i> Simpan</button>
        <a href="<?php echo e(route('pokja.index')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-arrow-circle-left fa-fw fa-sm"></i>Kembali</a>
        </form>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sbadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simprodata\resources\views/datapokja/tambahdatapokja.blade.php ENDPATH**/ ?>