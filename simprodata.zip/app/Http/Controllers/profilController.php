<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
class profilController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = \App\User::findOrfail($id);
        return view('profil.show',['user' => $user]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $profil = \App\User::findOrfail($id);
        return view('profil.edit',['profil' => $profil]);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $vslidation = Validator::make($request->All(),[
            "name" => "required"
        ])->validated();

        $profil = \App\User::findOrfail($id);
        $profil->name = $request->get('name');
        $profil->telpon = $request->get('telpon');
        $profil->alamat = $request->get('alamat');
        if ($request->file('avatar')) {

            if ($profil->avatar && file_exists(storage_path('app/public/'.$profil->avatar))){
                Storage::delete('public/'.$profil->avatar);
            }
            $file = $request->file('avatar')->store('avatar','public');
            $profil->avatar = $file;
        }
        $profil->save();
        return redirect()->back()->with('status','Data Berhasil diupdate');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function __construct()
    {
        $this->middleware('auth');
    }
}
