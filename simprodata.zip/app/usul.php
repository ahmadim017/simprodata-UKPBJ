<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class usul extends Model
{
    protected $table = "usul";
}
