<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class dana extends Model
{
    protected $table = "sumberdana";
}
