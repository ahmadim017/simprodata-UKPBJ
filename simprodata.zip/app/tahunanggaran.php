<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tahunanggaran extends Model
{
    protected $table = "tahunanggaran";
}
